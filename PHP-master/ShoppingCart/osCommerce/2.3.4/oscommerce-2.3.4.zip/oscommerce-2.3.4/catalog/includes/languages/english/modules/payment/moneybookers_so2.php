<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_MONEYBOOKERS_SO2_TEXT_TITLE', 'Moneybookers - Nordea Solo (Finland)');
  define('MODULE_PAYMENT_MONEYBOOKERS_SO2_TEXT_PUBLIC_TITLE', 'Nordea Solo');
  define('MODULE_PAYMENT_MONEYBOOKERS_SO2_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="http://www.moneybookers.com/partners/oscommerce" target="_blank" style="text-decoration: underline; font-weight: bold;">Visit Moneybookers Website</a>');
?>
