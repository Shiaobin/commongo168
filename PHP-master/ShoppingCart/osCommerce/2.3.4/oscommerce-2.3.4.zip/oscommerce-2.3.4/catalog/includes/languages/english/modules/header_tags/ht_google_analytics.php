<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_GOOGLE_ANALYTICS_TITLE', 'Google Analytics');
  define('MODULE_HEADER_TAGS_GOOGLE_ANALYTICS_DESCRIPTION', 'Add Google Analytics to the shop');
?>
