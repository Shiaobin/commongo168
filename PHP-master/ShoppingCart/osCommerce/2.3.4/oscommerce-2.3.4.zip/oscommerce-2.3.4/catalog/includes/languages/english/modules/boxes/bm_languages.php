<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_LANGUAGES_TITLE', 'Languages');
  define('MODULE_BOXES_LANGUAGES_DESCRIPTION', 'Show available languages');
  define('MODULE_BOXES_LANGUAGES_BOX_TITLE', 'Languages');
?>
