<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_TITLE', 'Latest Add-Ons');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DESCRIPTION', 'Show the latest osCommerce Add-Ons');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_DATE', 'Date');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_FEED_ERROR', 'Could not connect to the osCommerce Add-Ons feed. The next attempt will be performed within 24 hours.');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_SITE', 'Visit the osCommerce Add-Ons Site');
define('MODULE_ADMIN_DASHBOARD_LATEST_ADDONS_ICON_RSS', 'Subscribe to the osCommerce Add-Ons RSS Feed');
?>
