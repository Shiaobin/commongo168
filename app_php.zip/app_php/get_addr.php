<?php

//send a address which encode to json format
//Format: http://xxxxxxx

$addr="http://www.pinchenzhai.com";


$response["addr"]=$addr;

echo json_encode($response);




?>
