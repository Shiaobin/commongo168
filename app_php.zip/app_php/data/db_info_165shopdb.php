<?php
$SERV = "61.221.173.165:3306";
$USER = "mudiTest";
$PASS = "57@daon";
$DBNM = "shopdb";
?>
