<?php

    global $_DB;

    $_DB['host'] = "127.0.0.1";

    $_DB['username'] = "root";

    $_DB['password'] = "daon0827";

    $_DB['dbname'] = "pinchenzhai";

?>

