
<?php

    global $_DB;

    $_DB['host'] = "61.221.173.165:3306";

    $_DB['username'] = "mudiTest";

    $_DB['password'] = "57@daon";

    $_DB['dbname'] = "shopdb";

?>
